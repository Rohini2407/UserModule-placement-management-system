//to demonstrate UserService methods
package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;

@Service
@Transactional
public class UserService {
	
	@Autowired
	private UserRepository repo;//dependency in the form of object reference
	
	//create and update
	public void save(User user) {
		repo.save(user); //jpaRepo
	}
    
	//retrieve single value
	public User get(long id) {
		return repo.findById(id).get();
	}
	
	//retrieve all 
	public List<User> listAll(){
		return repo.findAll();
	}
	
	//delete
	public void delete(long id) {
		repo.deleteById(id);
	}
}
